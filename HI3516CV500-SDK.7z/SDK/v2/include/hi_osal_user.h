#ifndef __HI_OSAL_USER__
#define __HI_OSAL_USER__

#ifndef PROT_READ
#define PROT_READ
#endif
#ifndef PROT_WRITE
#define PROT_WRITE
#endif
#ifndef MAP_SHARED
#define MAP_SHARED
#endif
#ifndef MAP_FAILED
#define MAP_FAILED (NULL)
#endif

#endif
