/*
 * Copyright (C) Hisilicon Technologies Co., Ltd. 2012-2019. All rights reserved.
 * Description: hi_comm_ao.h
 * Author: Hisilicon multimedia software group
 * Create: 2009/5/5
 * History                 :
 *  1.Date                 :   2009/5/5
 *    Modification         :   Created file
 */

#ifndef __HI_COMM_AO_H__
#define __HI_COMM_AO_H__

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */




#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_COMM_AO_H__ */

